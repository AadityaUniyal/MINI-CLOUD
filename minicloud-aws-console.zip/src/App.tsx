/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Cpu, 
  HardDrive, 
  Network, 
  ShieldCheck, 
  Users, 
  Activity, 
  Settings, 
  Search, 
  Bell, 
  ChevronRight, 
  Play, 
  Square, 
  RefreshCw, 
  Plus, 
  Database, 
  Cloud, 
  Terminal,
  MessageSquare,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Menu,
  X,
  ExternalLink,
  Globe,
  Lock,
  Zap,
  BarChart3,
  Server,
  Box,
  Layers,
  History,
  HelpCircle,
  Trash2,
  MoreVertical
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { cn } from './lib/utils';

// --- Types ---

interface Instance {
  id: string;
  name: string;
  status: 'running' | 'stopped' | 'pending' | 'error';
  type: string;
  az: string;
  publicIp: string;
  amiId?: string;
  keyName?: string;
  securityGroups?: string[];
  launchTime?: string;
}

interface Bucket {
  name: string;
  region: string;
  creationDate: string;
  size: string;
}

interface VPC {
  id: string;
  name: string;
  cidr: string;
  status: string;
}

interface Role {
  name: string;
  id: string;
  arn: string;
  creationDate: string;
}

interface Policy {
  name: string;
  arn: string;
  description?: string;
}

// --- Mock Data ---

const USAGE_DATA = [
  { time: '00:00', cpu: 45, ram: 62, net: 12 },
  { time: '04:00', cpu: 32, ram: 58, net: 8 },
  { time: '08:00', cpu: 65, ram: 75, net: 45 },
  { time: '12:00', cpu: 88, ram: 82, net: 92 },
  { time: '16:00', cpu: 72, ram: 78, net: 68 },
  { time: '20:00', cpu: 55, ram: 70, net: 35 },
  { time: '23:59', cpu: 48, ram: 65, net: 18 },
];

const COST_DATA = [
  { name: 'Compute', value: 450 },
  { name: 'Storage', value: 280 },
  { name: 'Network', value: 120 },
  { name: 'Database', value: 310 },
];

const COLORS = ['#f97316', '#3b82f6', '#10b981', '#8b5cf6'];

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active?: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={cn(
      "flex items-center gap-3 w-full px-4 py-2.5 rounded-lg transition-all duration-200 group",
      active 
        ? "bg-orange-500/10 text-orange-500 border border-orange-500/20" 
        : "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200"
    )}
  >
    <Icon size={18} className={cn("transition-transform duration-200", active ? "scale-110" : "group-hover:scale-110")} />
    <span className="text-sm font-medium">{label}</span>
    {active && (
      <motion.div 
        layoutId="sidebar-active"
        className="ml-auto w-1 h-4 bg-orange-500 rounded-full"
      />
    )}
  </button>
);

const StatCard = ({ icon: Icon, label, value, trend, trendValue }: { icon: any, label: string, value: string, trend: 'up' | 'down' | 'neutral', trendValue: string }) => (
  <div className="glass-card p-5 flex flex-col gap-4">
    <div className="flex items-center justify-between">
      <div className="p-2 rounded-lg bg-zinc-800/50 text-zinc-400">
        <Icon size={20} />
      </div>
      <div className={cn(
        "flex items-center gap-1 text-xs font-medium",
        trend === 'up' ? "text-emerald-500" : trend === 'down' ? "text-rose-500" : "text-zinc-500"
      )}>
        {trend === 'up' ? <ArrowUpRight size={14} /> : trend === 'down' ? <ArrowDownRight size={14} /> : <Activity size={14} />}
        {trendValue}
      </div>
    </div>
    <div>
      <p className="text-xs text-zinc-500 font-medium uppercase tracking-wider">{label}</p>
      <h3 className="text-2xl font-bold mt-1 tracking-tight">{value}</h3>
    </div>
  </div>
);

const SectionHeader = ({ title, description, action }: { title: string, description: string, action?: React.ReactNode }) => (
  <div className="flex items-center justify-between mb-6">
    <div>
      <h2 className="text-xl font-bold tracking-tight text-white">{title}</h2>
      <p className="text-sm text-zinc-500 mt-1">{description}</p>
    </div>
    {action}
  </div>
);

const StatusPill = ({ status }: { status: string }) => {
  const styles = {
    running: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    stopped: "bg-zinc-500/10 text-zinc-400 border-zinc-500/20",
    pending: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    error: "bg-rose-500/10 text-rose-500 border-rose-500/20",
  }[status] || "bg-zinc-500/10 text-zinc-400 border-zinc-500/20";

  return (
    <span className={cn("status-pill border", styles)}>
      {status}
    </span>
  );
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [instances, setInstances] = useState<Instance[]>([]);
  const [buckets, setBuckets] = useState<Bucket[]>([]);
  const [vpcs, setVpcs] = useState<VPC[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [stats, setStats] = useState({ instances: 0, buckets: 0, vpcs: 0, roles: 0, isMock: true });
  const [loading, setLoading] = useState(true);
  const [configStatus, setConfigStatus] = useState<{ hasCredentials: boolean, region: string }>({ hasCredentials: false, region: 'us-east-1' });
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);
  
  // AI Chat State
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: "Hello! I'm your MiniCloud AI assistant. How can I help you manage your infrastructure today?" }
  ]);
  const [input, setInput] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Modals
  const [showLaunchModal, setShowLaunchModal] = useState(false);
  const [launchData, setLaunchData] = useState({ name: '', type: 't2.micro' });

  const [showRoleModal, setShowRoleModal] = useState(false);
  const [roleData, setRoleData] = useState({ name: '', description: '' });

  const [showBucketModal, setShowBucketModal] = useState(false);
  const [bucketData, setBucketData] = useState({ name: '', region: 'us-east-1' });

  const [showVpcModal, setShowVpcModal] = useState(false);
  const [vpcData, setVpcData] = useState({ name: '', cidr: '10.0.0.0/16' });

  const [showPolicyModal, setShowPolicyModal] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [rolePolicies, setRolePolicies] = useState<Policy[]>([]);

  const [selectedInstance, setSelectedInstance] = useState<Instance | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const [instRes, buckRes, vpcRes, roleRes, policyRes, configRes, statsRes] = await Promise.all([
        fetch('/api/compute/instances'),
        fetch('/api/storage/buckets'),
        fetch('/api/network/vpcs'),
        fetch('/api/security/roles'),
        fetch('/api/security/policies'),
        fetch('/api/config/status'),
        fetch('/api/overview/stats')
      ]);
      
      const instData = await instRes.json();
      const buckData = await buckRes.json();
      const vpcData = await vpcRes.json();
      const roleData = await roleRes.json();
      const policyData = await policyRes.json();
      const configData = await configRes.json();
      const statsData = await statsRes.json();

      setInstances(Array.isArray(instData) ? instData : []);
      setBuckets(Array.isArray(buckData) ? buckData : []);
      setVpcs(Array.isArray(vpcData) ? vpcData : []);
      setRoles(Array.isArray(roleData) ? roleData : []);
      setPolicies(Array.isArray(policyData) ? policyData : []);
      setConfigStatus(configData);
      if (!statsData.error) setStats(statsData);

      if (instData.error || buckData.error || vpcData.error || roleData.error || policyData.error || statsData.error) {
        showToast(instData.error || buckData.error || vpcData.error || roleData.error || policyData.error || statsData.error, "error");
      }
    } catch (err) {
      console.error("Failed to fetch cloud data:", err);
      showToast("Failed to sync with cloud services", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleInstanceAction = async (id: string, action: 'start' | 'stop' | 'terminate') => {
    try {
      const res = await fetch(`/api/compute/instances/${id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message);
        fetchData(); // Refresh data
      } else {
        showToast(data.error || "Action failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleLaunchInstance = async () => {
    if (!launchData.name) return showToast("Instance name is required", "error");
    try {
      const res = await fetch('/api/compute/instances', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(launchData)
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Instance ${data.instanceId} launched successfully!`);
        setShowLaunchModal(false);
        fetchData();
      } else {
        showToast(data.error || "Launch failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleCreateRole = async () => {
    if (!roleData.name) return showToast("Role name is required", "error");
    try {
      const res = await fetch('/api/security/roles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(roleData)
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Role ${data.roleName} created successfully!`);
        setShowRoleModal(false);
        fetchData();
      } else {
        showToast(data.error || "Role creation failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleDeleteRole = async (name: string) => {
    try {
      const res = await fetch(`/api/security/roles/${name}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message);
        fetchData();
      } else {
        showToast(data.error || "Delete failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const fetchRolePolicies = async (roleName: string) => {
    try {
      const res = await fetch(`/api/security/roles/${roleName}/policies`);
      const data = await res.json();
      setRolePolicies(Array.isArray(data) ? data : []);
    } catch (err) {
      showToast("Failed to fetch role policies", "error");
    }
  };

  const handleManagePolicies = (role: Role) => {
    setSelectedRole(role);
    fetchRolePolicies(role.name);
    setShowPolicyModal(true);
  };

  const handleAttachPolicy = async (policyArn: string) => {
    if (!selectedRole) return;
    try {
      const res = await fetch('/api/security/role-policies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roleName: selectedRole.name, policyArn })
      });
      const data = await res.json();
      if (data.success) {
        showToast("Policy attached successfully!");
        fetchRolePolicies(selectedRole.name);
      } else {
        showToast(data.error || "Failed to attach policy", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleCreateBucket = async () => {
    if (!bucketData.name) return showToast("Bucket name is required", "error");
    try {
      const res = await fetch('/api/storage/buckets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bucketData)
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message);
        setShowBucketModal(false);
        fetchData();
      } else {
        showToast(data.error || "Creation failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleDeleteBucket = async (name: string) => {
    try {
      const res = await fetch(`/api/storage/buckets/${name}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message);
        fetchData();
      } else {
        showToast(data.error || "Delete failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleCreateVpc = async () => {
    if (!vpcData.name) return showToast("VPC name is required", "error");
    try {
      const res = await fetch('/api/network/vpcs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(vpcData)
      });
      const data = await res.json();
      if (data.success) {
        showToast(`VPC ${data.vpcId} created successfully!`);
        setShowVpcModal(false);
        fetchData();
      } else {
        showToast(data.error || "Creation failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleDeleteVpc = async (id: string) => {
    try {
      const res = await fetch(`/api/network/vpcs/${id}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message);
        fetchData();
      } else {
        showToast(data.error || "Delete failed", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleDetachPolicy = async (policyArn: string) => {
    if (!selectedRole) return;
    try {
      const res = await fetch('/api/security/role-policies', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roleName: selectedRole.name, policyArn })
      });
      const data = await res.json();
      if (data.success) {
        showToast("Policy detached successfully!");
        fetchRolePolicies(selectedRole.name);
      } else {
        showToast(data.error || "Failed to detach policy", "error");
      }
    } catch (err) {
      showToast("Network error", "error");
    }
  };

  const handleAiChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isAiThinking) return;

    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setIsAiThinking(true);

    try {
      const ai = new GoogleGenAI({ apiKey: (import.meta as any).env.VITE_GEMINI_API_KEY || "GEMINI_API_KEY" });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `You are an AWS Cloud Expert Assistant for MiniCloud. 
        Current Context: ${instances.length} EC2 instances, ${buckets.length} S3 buckets.
        User Question: ${userMsg}`,
        config: {
          systemInstruction: "Be concise, professional, and helpful. Use technical cloud terminology."
        }
      });
      
      setMessages(prev => [...prev, { role: 'ai', text: response.text || "I'm sorry, I couldn't process that." }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'ai', text: "I'm having trouble connecting to my brain right now. Please try again later." }]);
    } finally {
      setIsAiThinking(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-[#27272A] bg-[#0A0A0B] flex flex-col p-4">
        <div className="flex items-center gap-3 px-2 mb-8">
          <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center text-white font-bold">
            <Cloud size={20} />
          </div>
          <span className="text-lg font-bold tracking-tighter text-white">MINI-CLOUD</span>
        </div>

        <nav className="flex-1 space-y-1">
          <SidebarItem icon={LayoutDashboard} label="Overview" active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} />
          <SidebarItem icon={Cpu} label="EC2 Instances" active={activeTab === 'compute'} onClick={() => setActiveTab('compute')} />
          <SidebarItem icon={HardDrive} label="S3 Buckets" active={activeTab === 'storage'} onClick={() => setActiveTab('storage')} />
          <SidebarItem icon={Network} label="VPC Networking" active={activeTab === 'networking'} onClick={() => setActiveTab('networking')} />
          <SidebarItem icon={ShieldCheck} label="IAM & Security" active={activeTab === 'security'} onClick={() => setActiveTab('security')} />
          <SidebarItem icon={Activity} label="CloudWatch" active={activeTab === 'monitoring'} onClick={() => setActiveTab('monitoring')} />
          <SidebarItem icon={Database} label="RDS Clusters" active={activeTab === 'database'} onClick={() => setActiveTab('database')} />
        </nav>

        <div className="mt-auto pt-4 border-t border-[#27272A] space-y-1">
          <SidebarItem icon={Settings} label="Settings" onClick={() => {}} />
          <SidebarItem icon={HelpCircle} label="Documentation" onClick={() => {}} />
          {!configStatus.hasCredentials && (
            <div className="p-4 mt-4 glass-card bg-orange-500/5 border-orange-500/10">
              <p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest mb-1">AWS Integration</p>
              <p className="text-xs text-zinc-400 leading-relaxed">Connect your real AWS account for live management.</p>
              <button className="mt-3 w-full py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors">
                Connect Account
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-[#0A0A0B]">
        {/* Header */}
        <header className="h-16 border-b border-[#27272A] flex items-center justify-between px-8 bg-[#0A0A0B]/80 backdrop-blur-md z-10">
          <div className="flex items-center gap-6 flex-1 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-bold text-zinc-500 uppercase tracking-widest">
              <Globe size={14} />
              Region: <span className="text-white">{configStatus.region}</span>
            </div>
            <div className="h-4 w-px bg-[#27272A]"></div>
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={16} />
              <input 
                type="text" 
                placeholder="Search resources, services, or documentation..." 
                className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className={cn(
              "flex items-center gap-1 px-3 py-1.5 rounded-full border text-[10px] font-bold uppercase tracking-widest",
              configStatus.hasCredentials 
                ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" 
                : "bg-amber-500/10 border-amber-500/20 text-amber-500"
            )}>
              <span className={cn("w-1.5 h-1.5 rounded-full animate-pulse", configStatus.hasCredentials ? "bg-emerald-500" : "bg-amber-500")}></span>
              {configStatus.hasCredentials ? "Live" : "Mock Mode"}
            </div>
            <button className="p-2 text-zinc-400 hover:text-white transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-orange-500 rounded-full border-2 border-[#0A0A0B]"></span>
            </button>
            <div className="h-8 w-px bg-[#27272A]"></div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs font-bold text-white">Aaditya Uniyal</p>
                <p className="text-[10px] text-zinc-500">Root Account</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-rose-500 flex items-center justify-center text-white font-bold text-xs">
                AU
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div 
                key="overview"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                <div className="flex items-center justify-between">
                  <SectionHeader 
                    title="Console Home" 
                    description="Welcome back. Here's a snapshot of your global infrastructure."
                  />
                  <div className="flex items-center gap-3">
                    <button className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-2">
                      <History size={14} />
                      Recent Activity
                    </button>
                    <button className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-2">
                      <Plus size={14} />
                      Create Resource
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <StatCard icon={Cpu} label="EC2 Instances" value={String(stats.instances ?? 0)} trend={stats.isMock ? "neutral" : "up"} trendValue={stats.isMock ? "Mock" : "Live"} />
                  <StatCard icon={HardDrive} label="S3 Buckets" value={String(stats.buckets ?? 0)} trend={stats.isMock ? "neutral" : "up"} trendValue={stats.isMock ? "Mock" : "Live"} />
                  <StatCard icon={Network} label="VPCs" value={String(stats.vpcs ?? 0)} trend={stats.isMock ? "neutral" : "up"} trendValue={stats.isMock ? "Mock" : "Live"} />
                  <StatCard icon={ShieldCheck} label="IAM Roles" value={String(stats.roles ?? 0)} trend={stats.isMock ? "neutral" : "up"} trendValue={stats.isMock ? "Mock" : "Live"} />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 glass-card p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <Activity size={16} className="text-orange-500" />
                        CloudWatch Metrics
                      </h3>
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1 text-[10px] font-bold text-orange-500">
                          <span className="w-2 h-2 rounded-full bg-orange-500"></span> CPU
                        </span>
                        <span className="flex items-center gap-1 text-[10px] font-bold text-blue-500">
                          <span className="w-2 h-2 rounded-full bg-blue-500"></span> RAM
                        </span>
                      </div>
                    </div>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={USAGE_DATA}>
                          <defs>
                            <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorRam" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#27272A" vertical={false} />
                          <XAxis dataKey="time" stroke="#52525B" fontSize={10} tickLine={false} axisLine={false} />
                          <YAxis stroke="#52525B" fontSize={10} tickLine={false} axisLine={false} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#121214', border: '1px solid #27272A', borderRadius: '8px', fontSize: '12px' }}
                            itemStyle={{ color: '#E4E4E7' }}
                          />
                          <Area type="monotone" dataKey="cpu" stroke="#f97316" strokeWidth={2} fillOpacity={1} fill="url(#colorCpu)" />
                          <Area type="monotone" dataKey="ram" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorRam)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="glass-card p-6">
                    <h3 className="text-sm font-bold text-white mb-6 flex items-center gap-2">
                      <Zap size={16} className="text-orange-500" />
                      Cost Explorer
                    </h3>
                    <div className="h-[200px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={COST_DATA}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {COST_DATA.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#121214', border: '1px solid #27272A', borderRadius: '8px', fontSize: '12px' }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-4 space-y-3">
                      {COST_DATA.map((item, i) => (
                        <div key={i} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }}></div>
                            <span className="text-zinc-400">{item.name}</span>
                          </div>
                          <span className="text-white font-bold">${item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="glass-card p-6 flex items-center gap-4 hover:bg-zinc-800/50 transition-colors cursor-pointer group">
                    <div className="p-3 rounded-xl bg-orange-500/10 text-orange-500 group-hover:scale-110 transition-transform">
                      <Server size={24} />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Compute Optimizer</h4>
                      <p className="text-xs text-zinc-500">3 recommendations found</p>
                    </div>
                  </div>
                  <div className="glass-card p-6 flex items-center gap-4 hover:bg-zinc-800/50 transition-colors cursor-pointer group">
                    <div className="p-3 rounded-xl bg-blue-500/10 text-blue-500 group-hover:scale-110 transition-transform">
                      <ShieldCheck size={24} />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Security Hub</h4>
                      <p className="text-xs text-zinc-500">No critical issues detected</p>
                    </div>
                  </div>
                  <div className="glass-card p-6 flex items-center gap-4 hover:bg-zinc-800/50 transition-colors cursor-pointer group">
                    <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-500 group-hover:scale-110 transition-transform">
                      <Globe size={24} />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Global Accelerator</h4>
                      <p className="text-xs text-zinc-500">12 edge locations active</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'compute' && (
              <motion.div 
                key="compute"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <SectionHeader 
                  title="EC2 Instances" 
                  description="Manage your virtual servers in the cloud. Launch, stop, or terminate instances."
                  action={
                    <div className="flex items-center gap-3">
                      <button className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors">
                        Actions
                      </button>
                      <button 
                        onClick={() => setShowLaunchModal(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                      >
                        <Plus size={16} />
                        Launch Instance
                      </button>
                    </div>
                  }
                />

                <div className="glass-card overflow-hidden">
                  <div className="grid grid-cols-[40px_1.5fr_1fr_1fr_1fr_100px] items-center p-4 border-b border-[#27272A] bg-zinc-900/50">
                    <div className="w-4 h-4 border border-zinc-700 rounded"></div>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Instance Name</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Status</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Type</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Public IP</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Actions</span>
                  </div>
                  <div className="divide-y divide-[#27272A]">
                    {instances.map((vm) => (
                      <div 
                        key={vm.id} 
                        onClick={() => setSelectedInstance(vm)}
                        className="grid grid-cols-[40px_1.5fr_1fr_1fr_1fr_100px] items-center p-4 hover:bg-[#18181B] transition-colors cursor-pointer group"
                      >
                        <div className="w-4 h-4 border border-zinc-700 rounded"></div>
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-white">{vm.name}</span>
                          <span className="text-[10px] text-zinc-500 font-mono">{vm.id}</span>
                        </div>
                        <div>
                          <StatusPill status={vm.status} />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xs text-zinc-300">{vm.type}</span>
                          <span className="text-[10px] text-zinc-500">{vm.az}</span>
                        </div>
                        <div>
                          <span className="text-xs text-zinc-400 font-mono">{vm.publicIp}</span>
                        </div>
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={(e) => { e.stopPropagation(); handleInstanceAction(vm.id, vm.status === 'running' ? 'stop' : 'start'); }}
                            className="p-1.5 text-zinc-500 hover:text-white hover:bg-zinc-800 rounded-md transition-all"
                            title={vm.status === 'running' ? 'Stop Instance' : 'Start Instance'}
                          >
                            {vm.status === 'running' ? <Square size={14} /> : <Play size={14} />}
                          </button>
                          <button 
                            onClick={(e) => { e.stopPropagation(); handleInstanceAction(vm.id, 'terminate'); }}
                            className="p-1.5 text-zinc-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-md transition-all"
                            title="Terminate Instance"
                          >
                            <Trash2 size={14} />
                          </button>
                          <button 
                            onClick={(e) => { e.stopPropagation(); fetchData(); }}
                            className="p-1.5 text-zinc-500 hover:text-white hover:bg-zinc-800 rounded-md transition-all"
                            title="Refresh"
                          >
                            <RefreshCw size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'security' && (
              <motion.div 
                key="security"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <SectionHeader 
                  title="IAM Roles" 
                  description="Manage user permissions and access control. Create roles and assign policies."
                  action={
                    <button 
                      onClick={() => setShowRoleModal(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                    >
                      <Plus size={16} />
                      Create Role
                    </button>
                  }
                />

                <div className="glass-card overflow-hidden">
                  <div className="grid grid-cols-[1.5fr_2fr_1fr_100px] items-center p-4 border-b border-[#27272A] bg-zinc-900/50">
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Role Name</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">ARN</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Created</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Actions</span>
                  </div>
                  <div className="divide-y divide-[#27272A]">
                    {roles.map((role) => (
                      <div key={role.id} className="grid grid-cols-[1.5fr_2fr_1fr_100px] items-center p-4 hover:bg-[#18181B] transition-colors">
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-white">{role.name}</span>
                          <span className="text-[10px] text-zinc-500 font-mono">{role.id}</span>
                        </div>
                        <div>
                          <span className="text-xs text-zinc-400 font-mono truncate block max-w-[300px]" title={role.arn}>
                            {role.arn}
                          </span>
                        </div>
                        <div>
                          <span className="text-xs text-zinc-300">{new Date(role.creationDate).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleManagePolicies(role)}
                            className="p-1.5 text-zinc-500 hover:text-white hover:bg-zinc-800 rounded-md transition-all"
                            title="Manage Policies"
                          >
                            <ShieldCheck size={14} />
                          </button>
                          <button 
                            onClick={() => handleDeleteRole(role.name)}
                            className="p-1.5 text-zinc-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-md transition-all"
                            title="Delete Role"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
            {activeTab === 'storage' && (
              <motion.div 
                key="storage"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                <SectionHeader 
                  title="S3 Buckets" 
                  description="Scalable object storage in the cloud. Store and retrieve any amount of data."
                  action={
                    <button 
                      onClick={() => setShowBucketModal(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                    >
                      <Plus size={16} />
                      Create Bucket
                    </button>
                  }
                />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {buckets.map((bucket, i) => (
                    <div key={i} className="glass-card p-6 group hover:border-orange-500/30 transition-all cursor-pointer relative">
                      <div className="flex items-center justify-between mb-4">
                        <div className="p-2 rounded-lg bg-orange-500/10 text-orange-500">
                          <HardDrive size={20} />
                        </div>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={(e) => { e.stopPropagation(); handleDeleteBucket(bucket.name); }}
                            className="p-1.5 text-zinc-600 hover:text-rose-500 hover:bg-rose-500/10 rounded-md transition-all"
                          >
                            <Trash2 size={14} />
                          </button>
                          <ExternalLink size={16} className="text-zinc-600 group-hover:text-orange-500 transition-colors" />
                        </div>
                      </div>
                      <h4 className="font-bold text-white">{bucket.name}</h4>
                      <p className="text-[10px] text-zinc-500 mt-1">{bucket.region}</p>
                      
                      <div className="mt-6 space-y-2">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-zinc-500">Storage Used</span>
                          <span className="text-zinc-300 font-medium">{bucket.size}</span>
                        </div>
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-zinc-500">Created</span>
                          <span className="text-zinc-300 font-medium">{new Date(bucket.creationDate).toLocaleDateString()}</span>
                        </div>
                      </div>
                      
                      <div className="mt-6 pt-4 border-t border-[#27272A] flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Lock size={12} className="text-emerald-500" />
                          <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Private</span>
                        </div>
                        <button className="text-[10px] font-bold text-zinc-500 hover:text-white uppercase tracking-widest transition-colors">
                          Manage
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'networking' && (
              <motion.div 
                key="networking"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <SectionHeader 
                  title="VPC Networking" 
                  description="Isolated cloud resources in your own virtual network."
                  action={
                    <button 
                      onClick={() => setShowVpcModal(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                    >
                      <Plus size={16} />
                      Create VPC
                    </button>
                  }
                />
                <div className="glass-card overflow-hidden">
                  <div className="grid grid-cols-[1.5fr_1fr_1fr_100px] items-center p-4 border-b border-[#27272A] bg-zinc-900/50">
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">VPC Name</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">CIDR Block</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Status</span>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Actions</span>
                  </div>
                  <div className="divide-y divide-[#27272A]">
                    {vpcs.map((vpc) => (
                      <div key={vpc.id} className="grid grid-cols-[1.5fr_1fr_1fr_100px] items-center p-4 hover:bg-[#18181B] transition-colors">
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-white">{vpc.name}</span>
                          <span className="text-[10px] text-zinc-500 font-mono">{vpc.id}</span>
                        </div>
                        <div>
                          <span className="text-xs text-zinc-300 font-mono">{vpc.cidr}</span>
                        </div>
                        <div>
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 text-[10px] font-bold uppercase tracking-widest border border-emerald-500/20">
                            {vpc.status}
                          </span>
                        </div>
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleDeleteVpc(vpc.id)}
                            className="p-1.5 text-zinc-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-md transition-all"
                            title="Delete VPC"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'monitoring' && (
              <motion.div 
                key="monitoring"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <SectionHeader 
                  title="CloudWatch" 
                  description="Monitor your resources and applications in real-time."
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="glass-card p-6">
                    <h4 className="text-sm font-bold text-white mb-4">Alarm Status</h4>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-lg">
                        <span className="text-xs text-emerald-500 font-bold uppercase tracking-widest">OK</span>
                        <span className="text-xs text-white">12 Alarms</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-amber-500/5 border border-amber-500/10 rounded-lg">
                        <span className="text-xs text-amber-500 font-bold uppercase tracking-widest">Warning</span>
                        <span className="text-xs text-white">0 Alarms</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'database' && (
              <motion.div 
                key="database"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <SectionHeader 
                  title="RDS Clusters" 
                  description="Fully managed relational database service."
                  action={
                    <button className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors">
                      <Plus size={16} />
                      Create Database
                    </button>
                  }
                />
                <div className="glass-card p-12 flex flex-col items-center justify-center text-center">
                  <div className="p-4 rounded-full bg-zinc-800/50 text-zinc-500 mb-4">
                    <Database size={32} />
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">No RDS Clusters Found</h4>
                  <p className="text-sm text-zinc-500 max-w-xs">You haven't created any database clusters yet. Start by launching a new RDS instance.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* AI Assistant Toggle */}
      <button 
        onClick={() => setIsAiOpen(!isAiOpen)}
        className="fixed bottom-8 right-8 w-14 h-14 bg-orange-500 hover:bg-orange-600 text-white rounded-full shadow-2xl shadow-orange-500/20 flex items-center justify-center transition-all hover:scale-110 z-50"
      >
        {isAiOpen ? <X size={24} /> : <Sparkles size={24} />}
      </button>

      {/* AI Assistant Panel */}
      <AnimatePresence>
        {isAiOpen && (
          <motion.div 
            initial={{ opacity: 0, x: 20, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.95 }}
            className="fixed bottom-24 right-8 w-96 h-[500px] glass-card shadow-2xl z-50 flex flex-col"
          >
            <div className="p-4 border-b border-[#27272A] flex items-center justify-between bg-zinc-900/50">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-orange-500/10 text-orange-500">
                  <Sparkles size={16} />
                </div>
                <span className="text-sm font-bold text-white">MiniCloud AI</span>
              </div>
              <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-1">
                <span className="w-1 h-1 rounded-full bg-emerald-500"></span>
                Online
              </span>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
              {messages.map((msg, i) => (
                <div 
                  key={i} 
                  className={cn(
                    "rounded-2xl p-3 text-sm max-w-[85%]",
                    msg.role === 'ai' 
                      ? "bg-zinc-800/50 text-zinc-300" 
                      : "bg-orange-500/10 text-orange-500 border border-orange-500/20 ml-auto"
                  )}
                >
                  {msg.text}
                </div>
              ))}
              {isAiThinking && (
                <div className="bg-zinc-800/50 rounded-2xl p-3 text-sm text-zinc-500 animate-pulse">
                  Thinking...
                </div>
              )}
            </div>

            <form onSubmit={handleAiChat} className="p-4 border-t border-[#27272A]">
              <div className="relative">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask AI assistant..." 
                  className="w-full bg-[#121214] border border-[#27272A] rounded-xl py-3 pl-4 pr-12 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                />
                <button 
                  type="submit"
                  disabled={isAiThinking}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-orange-500 hover:bg-orange-500/10 rounded-lg transition-colors disabled:opacity-50"
                >
                  <MessageSquare size={18} />
                </button>
              </div>
              <p className="text-[10px] text-zinc-600 mt-3 text-center">
                Powered by Gemini 3.1 Flash • MiniCloud Intelligence
              </p>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modals */}
      <AnimatePresence>
        {showLaunchModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLaunchModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md glass-card p-8 shadow-2xl"
            >
              <h3 className="text-xl font-bold text-white mb-2">Launch Instance</h3>
              <p className="text-sm text-zinc-500 mb-6">Configure your new virtual server.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Instance Name</label>
                  <input 
                    type="text" 
                    value={launchData.name}
                    onChange={(e) => setLaunchData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g. web-server-prod"
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Instance Type</label>
                  <select 
                    value={launchData.type}
                    onChange={(e) => setLaunchData(prev => ({ ...prev, type: e.target.value }))}
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  >
                    <option value="t2.micro">t2.micro (Free Tier Eligible)</option>
                    <option value="t3.medium">t3.medium</option>
                    <option value="c5.large">c5.large</option>
                    <option value="m5.xlarge">m5.xlarge</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 mt-8">
                <button 
                  onClick={() => setShowLaunchModal(false)}
                  className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleLaunchInstance}
                  className="flex-1 py-2.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Launch
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {showRoleModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRoleModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md glass-card p-8 shadow-2xl"
            >
              <h3 className="text-xl font-bold text-white mb-2">Create IAM Role</h3>
              <p className="text-sm text-zinc-500 mb-6">Define a new role with trust relationships.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Role Name</label>
                  <input 
                    type="text" 
                    value={roleData.name}
                    onChange={(e) => setRoleData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g. EC2ReadOnlyRole"
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Description</label>
                  <textarea 
                    value={roleData.description}
                    onChange={(e) => setRoleData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the purpose of this role..."
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors h-24 resize-none"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 mt-8">
                <button 
                  onClick={() => setShowRoleModal(false)}
                  className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleCreateRole}
                  className="flex-1 py-2.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Create Role
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {showBucketModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowBucketModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md glass-card p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Create S3 Bucket</h3>
                <button onClick={() => setShowBucketModal(false)} className="text-zinc-500 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Bucket Name</label>
                  <input 
                    type="text" 
                    value={bucketData.name}
                    onChange={(e) => setBucketData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g. my-awesome-bucket-2026"
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                  <p className="text-[10px] text-zinc-600 mt-2">Must be globally unique and follow DNS naming conventions.</p>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Region</label>
                  <select 
                    value={bucketData.region}
                    onChange={(e) => setBucketData(prev => ({ ...prev, region: e.target.value }))}
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors appearance-none"
                  >
                    <option value="us-east-1">US East (N. Virginia)</option>
                    <option value="us-east-2">US East (Ohio)</option>
                    <option value="us-west-1">US West (N. California)</option>
                    <option value="us-west-2">US West (Oregon)</option>
                    <option value="eu-west-1">Europe (Ireland)</option>
                    <option value="ap-southeast-1">Asia Pacific (Singapore)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 mt-8">
                <button 
                  onClick={() => setShowBucketModal(false)}
                  className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleCreateBucket}
                  className="flex-1 py-2.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Create Bucket
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {showVpcModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowVpcModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md glass-card p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Create VPC</h3>
                <button onClick={() => setShowVpcModal(false)} className="text-zinc-500 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">VPC Name</label>
                  <input 
                    type="text" 
                    value={vpcData.name}
                    onChange={(e) => setVpcData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g. Production-VPC"
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">IPv4 CIDR Block</label>
                  <input 
                    type="text" 
                    value={vpcData.cidr}
                    onChange={(e) => setVpcData(prev => ({ ...prev, cidr: e.target.value }))}
                    placeholder="e.g. 10.0.0.0/16"
                    className="w-full bg-[#121214] border border-[#27272A] rounded-lg py-2.5 px-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                  <p className="text-[10px] text-zinc-600 mt-2">The range of IPv4 addresses for the VPC.</p>
                </div>
              </div>

              <div className="flex items-center gap-3 mt-8">
                <button 
                  onClick={() => setShowVpcModal(false)}
                  className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleCreateVpc}
                  className="flex-1 py-2.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Create VPC
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {showPolicyModal && selectedRole && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPolicyModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl glass-card p-8 shadow-2xl flex flex-col max-h-[80vh]"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-white mb-1">Manage Policies</h3>
                  <p className="text-sm text-zinc-500">Role: <span className="text-orange-500 font-mono">{selectedRole.name}</span></p>
                </div>
                <button onClick={() => setShowPolicyModal(false)} className="text-zinc-500 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto space-y-8 custom-scrollbar pr-2">
                {/* Attached Policies */}
                <div>
                  <h4 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-4">Attached Policies</h4>
                  <div className="space-y-2">
                    {rolePolicies.length > 0 ? rolePolicies.map((p, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-lg group">
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-white">{p.name}</span>
                          <span className="text-[10px] text-zinc-500 font-mono">{p.arn}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest group-hover:hidden">Attached</span>
                          <button 
                            onClick={() => handleDetachPolicy(p.arn)}
                            className="hidden group-hover:block px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white text-[10px] font-bold uppercase tracking-widest rounded transition-all"
                          >
                            Detach
                          </button>
                        </div>
                      </div>
                    )) : (
                      <div className="p-4 border border-dashed border-[#27272A] rounded-lg text-center">
                        <p className="text-xs text-zinc-500">No policies attached to this role.</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Available Policies */}
                <div>
                  <h4 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-4">Available Policies</h4>
                  <div className="space-y-2">
                    {policies.filter(p => !rolePolicies.some(rp => rp.arn === p.arn)).map((p, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-zinc-900/50 border border-[#27272A] rounded-lg hover:border-orange-500/30 transition-colors group">
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-white">{p.name}</span>
                          <span className="text-[10px] text-zinc-500 font-mono">{p.arn}</span>
                          <p className="text-[10px] text-zinc-600 mt-1">{p.description}</p>
                        </div>
                        <button 
                          onClick={() => handleAttachPolicy(p.arn)}
                          className="px-3 py-1.5 bg-orange-500/10 hover:bg-orange-500 text-orange-500 hover:text-white text-[10px] font-bold uppercase tracking-widest rounded transition-all"
                        >
                          Attach
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-[#27272A]">
                <button 
                  onClick={() => setShowPolicyModal(false)}
                  className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {selectedInstance && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedInstance(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl glass-card p-8 shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-orange-500/10 text-orange-500">
                    <Cpu size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{selectedInstance.name}</h3>
                    <p className="text-xs text-zinc-500 font-mono">{selectedInstance.id}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <StatusPill status={selectedInstance.status} />
                  <button onClick={() => setSelectedInstance(null)} className="text-zinc-500 hover:text-white transition-colors">
                    <X size={20} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-8">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Instance Type</p>
                    <p className="text-sm text-white font-medium">{selectedInstance.type}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Availability Zone</p>
                    <p className="text-sm text-white font-medium">{selectedInstance.az}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Public IPv4 Address</p>
                    <p className="text-sm text-orange-500 font-mono">{selectedInstance.publicIp}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">AMI ID</p>
                    <p className="text-sm text-zinc-300 font-mono">{selectedInstance.amiId || '-'}</p>
                  </div>
                </div>

                <div className="h-px bg-[#27272A]"></div>

                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Key Pair Name</p>
                      <p className="text-sm text-white font-medium">{selectedInstance.keyName || '-'}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Launch Time</p>
                      <p className="text-sm text-white font-medium">
                        {selectedInstance.launchTime ? new Date(selectedInstance.launchTime).toLocaleString() : '-'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Security Groups</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedInstance.securityGroups && selectedInstance.securityGroups.length > 0 ? (
                        selectedInstance.securityGroups.map((sg, i) => (
                          <span key={i} className="px-2 py-1 bg-zinc-800 border border-[#27272A] rounded text-[10px] text-zinc-300 font-mono">
                            {sg}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-zinc-500 italic">No security groups attached</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="h-px bg-[#27272A]"></div>

                <div className="space-y-4">
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Instance Actions</p>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleInstanceAction(selectedInstance.id, selectedInstance.status === 'running' ? 'stop' : 'start'); }}
                      className={cn(
                        "flex-1 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2",
                        selectedInstance.status === 'running' 
                          ? "bg-zinc-800 hover:bg-zinc-700 text-white" 
                          : "bg-emerald-500 hover:bg-emerald-600 text-white"
                      )}
                    >
                      {selectedInstance.status === 'running' ? <Square size={14} /> : <Play size={14} />}
                      {selectedInstance.status === 'running' ? 'Stop Instance' : 'Start Instance'}
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleInstanceAction(selectedInstance.id, 'terminate'); }}
                      className="flex-1 py-2.5 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2"
                    >
                      <Trash2 size={14} />
                      Terminate
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-[#27272A]">
                <button 
                  onClick={() => setSelectedInstance(null)}
                  className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Close Details
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={cn(
              "fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 rounded-xl shadow-2xl z-[100] flex items-center gap-3 border",
              toast.type === 'success' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" : "bg-rose-500/10 border-rose-500/20 text-rose-500"
            )}
          >
            {toast.type === 'success' ? <ShieldCheck size={18} /> : <X size={18} />}
            <span className="text-sm font-bold">{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #27272A;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #3F3F46;
        }
      `}} />
    </div>
  );
}
