import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // --- AWS Clients (Lazy Initialization) ---
  let ec2Client: any = null;
  let s3Client: any = null;
  let cwClient: any = null;
  let iamClient: any = null;

  const getEC2Client = async () => {
    if (!ec2Client) {
      const { EC2Client } = await import("@aws-sdk/client-ec2");
      const credentials = {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
      };
      if (!credentials.accessKeyId || !credentials.secretAccessKey) return null;
      ec2Client = new EC2Client({ region: process.env.AWS_REGION || "us-east-1", credentials });
    }
    return ec2Client;
  };

  const getS3Client = async () => {
    if (!s3Client) {
      const { S3Client } = await import("@aws-sdk/client-s3");
      const credentials = {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
      };
      if (!credentials.accessKeyId || !credentials.secretAccessKey) return null;
      s3Client = new S3Client({ region: process.env.AWS_REGION || "us-east-1", credentials });
    }
    return s3Client;
  };

  const getIAMClient = async () => {
    if (!iamClient) {
      const { IAMClient } = await import("@aws-sdk/client-iam");
      const credentials = {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
      };
      if (!credentials.accessKeyId || !credentials.secretAccessKey) return null;
      iamClient = new IAMClient({ region: "aws-global", credentials });
    }
    return iamClient;
  };

  // --- API Routes ---

  app.get("/api/config/status", (req, res) => {
    res.json({
      hasCredentials: !!(process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY),
      region: process.env.AWS_REGION || "us-east-1"
    });
  });

  app.get("/api/compute/instances", async (req, res) => {
    const client = await getEC2Client();
    if (!client) {
      // Return mock data if no credentials
      return res.json([
        { 
          id: 'i-mock-01', 
          name: 'web-prod-01 (Mock)', 
          status: 'running', 
          type: 't3.medium', 
          az: 'us-east-1a', 
          publicIp: '54.23.1.45',
          amiId: 'ami-0c55b159cbfafe1f0',
          keyName: 'prod-key',
          securityGroups: ['sg-0123456789abcdef0 (web-sg)'],
          launchTime: new Date().toISOString()
        },
        { 
          id: 'i-mock-02', 
          name: 'api-gateway (Mock)', 
          status: 'running', 
          type: 'c5.large', 
          az: 'us-east-1b', 
          publicIp: '3.12.45.88',
          amiId: 'ami-0c55b159cbfafe1f0',
          keyName: 'prod-key',
          securityGroups: ['sg-0123456789abcdef1 (api-sg)'],
          launchTime: new Date().toISOString()
        },
      ]);
    }

    try {
      const { DescribeInstancesCommand } = await import("@aws-sdk/client-ec2");
      const data = await client.send(new DescribeInstancesCommand({}));
      const instances = data.Reservations?.flatMap(r => r.Instances || []).map(i => ({
        id: i.InstanceId,
        name: i.Tags?.find(t => t.Key === 'Name')?.Value || i.InstanceId,
        status: i.State?.Name,
        type: i.InstanceType,
        az: i.Placement?.AvailabilityZone,
        publicIp: i.PublicIpAddress || '-',
        amiId: i.ImageId,
        keyName: i.KeyName || '-',
        securityGroups: i.SecurityGroups?.map(sg => `${sg.GroupId} (${sg.GroupName})`) || [],
        launchTime: i.LaunchTime?.toISOString()
      })) || [];
      res.json(instances);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/compute/instances/:id/action", async (req, res) => {
    const { id } = req.params;
    const { action } = req.body; // 'start', 'stop', or 'terminate'
    const client = await getEC2Client();
    
    if (!client) return res.status(400).json({ error: "AWS credentials required for this action." });

    try {
      const { StartInstancesCommand, StopInstancesCommand, TerminateInstancesCommand } = await import("@aws-sdk/client-ec2");
      let command;
      if (action === 'start') command = new StartInstancesCommand({ InstanceIds: [id] });
      else if (action === 'stop') command = new StopInstancesCommand({ InstanceIds: [id] });
      else if (action === 'terminate') command = new TerminateInstancesCommand({ InstanceIds: [id] });
      else return res.status(400).json({ error: "Invalid action" });

      await client.send(command);
      res.json({ success: true, message: `Instance ${id} ${action}ed` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/compute/instances", async (req, res) => {
    const { name, type } = req.body;
    const client = await getEC2Client();
    if (!client) return res.status(400).json({ error: "AWS credentials required to launch instances." });

    try {
      const { RunInstancesCommand } = await import("@aws-sdk/client-ec2");
      const data = await client.send(new RunInstancesCommand({
        ImageId: "ami-0c55b159cbfafe1f0", // Amazon Linux 2 (example)
        InstanceType: type || "t2.micro",
        MinCount: 1,
        MaxCount: 1,
        TagSpecifications: [{
          ResourceType: "instance",
          Tags: [{ Key: "Name", Value: name || "New Instance" }]
        }]
      }));
      res.json({ success: true, instanceId: data.Instances?.[0].InstanceId });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/storage/buckets", async (req, res) => {
    const client = await getS3Client();
    if (!client) {
      return res.json([
        { name: 'minicloud-assets-mock', region: 'us-east-1', creationDate: new Date().toISOString(), size: '1.2 TB' },
      ]);
    }

    try {
      const { ListBucketsCommand } = await import("@aws-sdk/client-s3");
      const data = await client.send(new ListBucketsCommand({}));
      const buckets = data.Buckets?.map(b => ({
        name: b.Name,
        region: process.env.AWS_REGION || 'us-east-1',
        creationDate: b.CreationDate?.toISOString(),
        size: 'N/A' // S3 doesn't return size in ListBuckets
      })) || [];
      res.json(buckets);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/storage/buckets", async (req, res) => {
    const { name } = req.body;
    const client = await getS3Client();
    if (!client) return res.status(400).json({ error: "AWS credentials required to create buckets." });

    try {
      const { CreateBucketCommand } = await import("@aws-sdk/client-s3");
      await client.send(new CreateBucketCommand({ Bucket: name }));
      res.json({ success: true, message: `Bucket ${name} created` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/storage/buckets/:name", async (req, res) => {
    const { name } = req.params;
    const client = await getS3Client();
    if (!client) return res.status(400).json({ error: "AWS credentials required to delete buckets." });

    try {
      const { DeleteBucketCommand } = await import("@aws-sdk/client-s3");
      await client.send(new DeleteBucketCommand({ Bucket: name }));
      res.json({ success: true, message: `Bucket ${name} deleted` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/security/roles", async (req, res) => {
    const client = await getIAMClient();
    if (!client) {
      return res.json([
        { name: 'AdminRole-Mock', id: 'AROA-MOCK-01', arn: 'arn:aws:iam::123456789012:role/AdminRole', creationDate: new Date().toISOString() },
        { name: 'ReadOnly-Mock', id: 'AROA-MOCK-02', arn: 'arn:aws:iam::123456789012:role/ReadOnly', creationDate: new Date().toISOString() },
      ]);
    }

    try {
      const { ListRolesCommand } = await import("@aws-sdk/client-iam");
      const data = await client.send(new ListRolesCommand({}));
      const roles = data.Roles?.map(r => ({
        name: r.RoleName,
        id: r.RoleId,
        arn: r.Arn,
        creationDate: r.CreateDate?.toISOString()
      })) || [];
      res.json(roles);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/security/roles", async (req, res) => {
    const { name, description } = req.body;
    const client = await getIAMClient();
    if (!client) return res.status(400).json({ error: "AWS credentials required to create roles." });

    try {
      const { CreateRoleCommand } = await import("@aws-sdk/client-iam");
      const trustPolicy = JSON.stringify({
        Version: "2012-10-17",
        Statement: [{
          Effect: "Allow",
          Principal: { Service: "ec2.amazonaws.com" },
          Action: "sts:AssumeRole"
        }]
      });
      
      const data = await client.send(new CreateRoleCommand({
        RoleName: name,
        AssumeRolePolicyDocument: trustPolicy,
        Description: description || "Created via MiniCloud Console"
      }));
      res.json({ success: true, roleName: data.Role?.RoleName });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/security/roles/:name", async (req, res) => {
    const { name } = req.params;
    const client = await getIAMClient();
    if (!client) return res.status(400).json({ error: "AWS credentials required to delete roles." });

    try {
      const { DeleteRoleCommand } = await import("@aws-sdk/client-iam");
      await client.send(new DeleteRoleCommand({ RoleName: name }));
      res.json({ success: true, message: `Role ${name} deleted` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/security/policies", async (req, res) => {
    const client = await getIAMClient();
    if (!client) {
      return res.json([
        { name: 'AdministratorAccess', arn: 'arn:aws:iam::aws:policy/AdministratorAccess', description: 'Full access to AWS services' },
        { name: 'AmazonS3FullAccess', arn: 'arn:aws:iam::aws:policy/AmazonS3FullAccess', description: 'Full access to S3' },
        { name: 'AmazonEC2ReadOnlyAccess', arn: 'arn:aws:iam::aws:policy/AmazonEC2ReadOnlyAccess', description: 'Read-only access to EC2' },
      ]);
    }

    try {
      const { ListPoliciesCommand } = await import("@aws-sdk/client-iam");
      const data = await client.send(new ListPoliciesCommand({ Scope: "AWS", MaxItems: 50 })); // Just show AWS managed for now
      const policies = data.Policies?.map(p => ({
        name: p.PolicyName,
        arn: p.Arn,
        description: p.Description || "Managed Policy"
      })) || [];
      res.json(policies);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/security/roles/:name/policies", async (req, res) => {
    const { name } = req.params;
    const client = await getIAMClient();
    if (!client) {
      return res.json([
        { name: 'AmazonS3ReadOnlyAccess', arn: 'arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess' }
      ]);
    }

    try {
      const { ListAttachedRolePoliciesCommand } = await import("@aws-sdk/client-iam");
      const data = await client.send(new ListAttachedRolePoliciesCommand({ RoleName: name }));
      const policies = data.AttachedPolicies?.map(p => ({
        name: p.PolicyName,
        arn: p.PolicyArn
      })) || [];
      res.json(policies);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/security/role-policies", async (req, res) => {
    const { roleName, policyArn } = req.body;
    const client = await getIAMClient();
    if (!client) return res.status(400).json({ error: "AWS credentials required to attach policies." });

    try {
      const { AttachRolePolicyCommand } = await import("@aws-sdk/client-iam");
      await client.send(new AttachRolePolicyCommand({
        RoleName: roleName,
        PolicyArn: policyArn
      }));
      res.json({ success: true, message: `Policy attached to ${roleName}` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/security/role-policies", async (req, res) => {
    const { roleName, policyArn } = req.body;
    const client = await getIAMClient();
    if (!client) return res.status(400).json({ error: "AWS credentials required to detach policies." });

    try {
      const { DetachRolePolicyCommand } = await import("@aws-sdk/client-iam");
      await client.send(new DetachRolePolicyCommand({
        RoleName: roleName,
        PolicyArn: policyArn
      }));
      res.json({ success: true, message: `Policy detached from ${roleName}` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/network/vpcs", async (req, res) => {
    const client = await getEC2Client();
    if (!client) {
      return res.json([
        { id: 'vpc-mock-01', name: 'Main-VPC (Mock)', cidr: '10.0.0.0/16', status: 'available' },
      ]);
    }

    try {
      const { DescribeVpcsCommand } = await import("@aws-sdk/client-ec2");
      const data = await client.send(new DescribeVpcsCommand({}));
      const vpcs = data.Vpcs?.map(v => ({
        id: v.VpcId,
        name: v.Tags?.find(t => t.Key === 'Name')?.Value || v.VpcId,
        cidr: v.CidrBlock,
        status: v.State
      })) || [];
      res.json(vpcs);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/network/vpcs", async (req, res) => {
    const { name, cidr } = req.body;
    const client = await getEC2Client();
    if (!client) return res.status(400).json({ error: "AWS credentials required to create VPCs." });

    try {
      const { CreateVpcCommand, CreateTagsCommand } = await import("@aws-sdk/client-ec2");
      const data = await client.send(new CreateVpcCommand({ CidrBlock: cidr || "10.0.0.0/16" }));
      const vpcId = data.Vpc?.VpcId;
      
      if (vpcId && name) {
        await client.send(new CreateTagsCommand({
          Resources: [vpcId],
          Tags: [{ Key: "Name", Value: name }]
        }));
      }
      
      res.json({ success: true, vpcId });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/network/vpcs/:id", async (req, res) => {
    const { id } = req.params;
    const client = await getEC2Client();
    if (!client) return res.status(400).json({ error: "AWS credentials required to delete VPCs." });

    try {
      const { DeleteVpcCommand } = await import("@aws-sdk/client-ec2");
      await client.send(new DeleteVpcCommand({ VpcId: id }));
      res.json({ success: true, message: `VPC ${id} deleted` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/overview/stats", async (req, res) => {
    const ec2 = await getEC2Client();
    const s3 = await getS3Client();
    const iam = await getIAMClient();

    if (!ec2 || !s3 || !iam) {
      return res.json({
        instances: 2,
        buckets: 1,
        vpcs: 1,
        roles: 2,
        isMock: true
      });
    }

    try {
      const { DescribeInstancesCommand, DescribeVpcsCommand } = await import("@aws-sdk/client-ec2");
      const { ListBucketsCommand } = await import("@aws-sdk/client-s3");
      const { ListRolesCommand } = await import("@aws-sdk/client-iam");

      const [instData, vpcData, buckData, roleData] = await Promise.all([
        ec2.send(new DescribeInstancesCommand({})),
        ec2.send(new DescribeVpcsCommand({})),
        s3.send(new ListBucketsCommand({})),
        iam.send(new ListRolesCommand({}))
      ]);

      res.json({
        instances: instData.Reservations?.flatMap(r => r.Instances || []).length || 0,
        vpcs: vpcData.Vpcs?.length || 0,
        buckets: buckData.Buckets?.length || 0,
        roles: roleData.Roles?.length || 0,
        isMock: false
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // --- Vite Middleware ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`MiniCloud Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
